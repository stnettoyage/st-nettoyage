"use client";

import { motion } from "framer-motion";
import { Sparkles, Timer, BadgeEuro, UserCheck } from "lucide-react";

const reasons = [
  {
    title: "Travail soigné",
    description: "Chaque recoin est inspecté, chaque surface est traitée avec le plus grand soin pour un résultat impeccable.",
    icon: Sparkles,
  },
  {
    title: "Respect des délais",
    description: "Nous savons que votre temps est précieux. Nous intervenons ponctuellement et respectons le planning établi.",
    icon: Timer,
  },
  {
    title: "Tarifs clairs",
    description: "Pas de mauvaise surprise. Nos devis sont transparents, détaillés et adaptés à vos besoins réels.",
    icon: BadgeEuro,
  },
  {
    title: "Service professionnel",
    description: "Une équipe formée, courtoise et équipée pour répondre aux exigences les plus élevées du métier.",
    icon: UserCheck,
  },
];

export function WhyUs() {
  return (
    <section id="why-us" className="py-24 bg-primary text-primary-foreground relative overflow-hidden">
      {/* Background patterns */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-10 left-10 w-64 h-64 border-8 border-white rounded-full" />
        <div className="absolute bottom-10 right-10 w-96 h-96 border-8 border-white rounded-full opacity-20" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-sm font-bold tracking-widest uppercase mb-4 opacity-80">
              Pourquoi nous choisir ?
            </h2>
            <h3 className="text-3xl md:text-5xl font-bold mb-8 leading-tight">
              L'excellence au service de votre sérénité
            </h3>
            <p className="text-xl opacity-90 mb-10 leading-relaxed">
              Chez ST Nettoyage, nous ne nous contentons pas de nettoyer. 
              Nous créons des espaces où il fait bon vivre et travailler, 
              en vous libérant des contraintes logistiques.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <div className="bg-white/10 backdrop-blur-md px-6 py-4 rounded-2xl border border-white/20">
                <span className="text-3xl font-bold block">500+</span>
                <span className="text-xs uppercase tracking-wider opacity-70">Missions réussies</span>
              </div>
              <div className="bg-white/10 backdrop-blur-md px-6 py-4 rounded-2xl border border-white/20">
                <span className="text-3xl font-bold block">100%</span>
                <span className="text-xs uppercase tracking-wider opacity-70">Client fidèles</span>
              </div>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {reasons.map((reason, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white text-foreground p-8 rounded-2xl shadow-xl group hover:bg-accent transition-colors duration-300"
              >
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
                  <reason.icon className="h-6 w-6" />
                </div>
                <h4 className="text-lg font-bold mb-2">{reason.title}</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {reason.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
