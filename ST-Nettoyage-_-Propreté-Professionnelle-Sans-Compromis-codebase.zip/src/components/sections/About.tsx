"use client";

import { motion } from "framer-motion";
import { Shield, Clock, Target, EyeOff } from "lucide-react";

const values = [
  {
    title: "Sérieux",
    description: "Une approche rigoureuse pour chaque mission confiée.",
    icon: Shield,
  },
  {
    title: "Ponctualité",
    description: "Le respect de vos délais est notre priorité absolue.",
    icon: Clock,
  },
  {
    title: "Efficacité",
    description: "Des méthodes optimisées pour un résultat impeccable.",
    icon: Target,
  },
  {
    title: "Discrétion",
    description: "Une intervention invisible mais un résultat visible.",
    icon: EyeOff,
  },
];

export function About() {
  return (
    <section id="about" className="py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-4">
              À propos de ST Nettoyage
            </h2>
            <h3 className="text-3xl md:text-4xl font-bold mb-6 text-foreground">
              Votre partenaire confiance pour une propreté irréprochable
            </h3>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                ST Nettoyage est votre partenaire de confiance pour une propreté irréprochable, intervenant 
                auprès des <span className="text-foreground font-semibold">particuliers</span> et des <span className="text-foreground font-semibold">professionnels</span>. 
                Nous proposons des solutions adaptées : de l'entretien de logements privés et locations 
                courte durée aux contrats réguliers pour bureaux, immeubles et syndics.
              </p>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              Notre engagement : vous garantir une satisfaction totale grâce à une équipe dévouée, 
              formée et équipée des meilleurs outils.
            </p>
            
            <div className="grid grid-cols-2 gap-6">
              {values.map((value, index) => (
                <div key={index} className="flex gap-3">
                  <div className="mt-1 bg-primary/10 p-2 rounded-lg h-fit">
                    <value.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-bold text-foreground">{value.title}</h4>
                    <p className="text-sm text-muted-foreground">{value.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl border-8 border-white">
                <img 
                  src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/IMG_9086-resized-1766953906068.jpeg?width=8000&height=8000&resize=contain" 
                  alt="Nettoyage professionnel ST Nettoyage"
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Experience Badge */}
              <div className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground p-8 rounded-2xl shadow-xl hidden md:block">
                <span className="text-4xl font-bold block">Lyon</span>
                <span className="text-sm font-medium uppercase tracking-wider">& ses environs</span>
              </div>
            </motion.div>
        </div>
      </div>
    </section>
  );
}
