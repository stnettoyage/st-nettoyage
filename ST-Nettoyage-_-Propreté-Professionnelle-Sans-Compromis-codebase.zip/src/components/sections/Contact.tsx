"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin, Send, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

const formSchema = z.object({
  nom_complet: z.string().min(2, "Le nom est obligatoire"),
  telephone: z.string().min(10, "Le numéro de téléphone est obligatoire"),
  email: z.string().email("L'adresse email est invalide"),
  type_service: z.string().min(2, "Veuillez préciser le type de service"),
  message: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
  });

  const onSubmit = async (data: FormValues) => {
    setIsSubmitting(true);
    try {
      const response = await fetch("/api/devis", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Une erreur est survenue");
      }

      toast.success("Votre demande de devis a été envoyée avec succès !");
      reset();
    } catch (error: any) {
      console.error("Error submitting form:", error);
      toast.error(error.message || "Une erreur est survenue. Veuillez réessayer plus tard.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-4">
                Contactez-nous
              </h2>
              <h3 className="text-3xl md:text-4xl font-bold mb-6 text-foreground">
                Prêt pour une propreté sans compromis ?
              </h3>
              <p className="text-lg text-muted-foreground mb-10">
                Demandez votre devis gratuit dès aujourd'hui. Notre équipe vous répondra dans les plus brefs délais.
              </p>

              <div className="space-y-6">
                <a 
                  href="tel:0766398785" 
                  className="flex items-center gap-4 p-4 rounded-2xl bg-background border border-border hover:border-primary transition-all group"
                >
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <Phone className="h-6 w-6" />
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground block">Téléphone</span>
                    <span className="text-lg font-bold">07 66 39 87 85</span>
                  </div>
                </a>

                  <a 
                    href="mailto:st.nettoyagepro@gmail.com" 
                    className="flex items-center gap-4 p-4 rounded-2xl bg-background border border-border hover:border-primary transition-all group"
                  >
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                      <Mail className="h-6 w-6" />
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground block">Email</span>
                      <span className="text-lg font-bold">st.nettoyagepro@gmail.com</span>
                    </div>
                  </a>

                  <div className="flex items-center gap-4 p-4 rounded-2xl bg-background border border-border transition-all">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                      <MapPin className="h-6 w-6" />
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground block">Zone d'intervention</span>
                      <span className="text-lg font-bold text-foreground">Lyon et ses environs</span>
                    </div>
                  </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-background p-8 rounded-3xl shadow-xl border border-border"
            >
              <form className="space-y-6" onSubmit={handleSubmit(onSubmit)}>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Nom complet</label>
                    <Input 
                      {...register("nom_complet")}
                      placeholder="Jean Dupont" 
                      className="rounded-xl" 
                    />
                    {errors.nom_complet && (
                      <p className="text-xs text-destructive">{errors.nom_complet.message}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Téléphone</label>
                    <Input 
                      {...register("telephone")}
                      placeholder="06 00 00 00 00" 
                      className="rounded-xl" 
                    />
                    {errors.telephone && (
                      <p className="text-xs text-destructive">{errors.telephone.message}</p>
                    )}
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email</label>
                  <Input 
                    {...register("email")}
                    type="email" 
                    placeholder="jean@exemple.com" 
                    className="rounded-xl" 
                  />
                  {errors.email && (
                    <p className="text-xs text-destructive">{errors.email.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Type de service</label>
                  <Input 
                    {...register("type_service")}
                    placeholder="Ménage Airbnb, Résidence..." 
                    className="rounded-xl" 
                  />
                  {errors.type_service && (
                    <p className="text-xs text-destructive">{errors.type_service.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Message</label>
                  <Textarea 
                    {...register("message")}
                    placeholder="Dites-nous en plus sur vos besoins..." 
                    className="min-h-[120px] rounded-xl resize-none"
                  />
                </div>
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full rounded-xl h-12 text-lg gap-2"
                >
                  {isSubmitting ? (
                    <>Envoi en cours... <Loader2 className="h-5 w-5 animate-spin" /></>
                  ) : (
                    <>Envoyer la demande <Send className="h-5 w-5" /></>
                  )}
                </Button>
              </form>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
