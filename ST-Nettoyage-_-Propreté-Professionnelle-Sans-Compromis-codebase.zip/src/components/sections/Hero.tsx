"use client";

import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background with overlay */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/IMG_9544-resized-1766953906086.jpeg?width=8000&height=8000&resize=contain')",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-background/20" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6">
              <CheckCircle2 className="h-4 w-4" />
              <span>Service professionnel à Lyon & ses environs</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight text-foreground mb-6 leading-tight">
              ST Nettoyage – La propreté <span className="text-primary italic font-serif">professionnelle</span>, sans compromis
            </h1>
            
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl leading-relaxed">
                Ménage et entretien pour <span className="text-foreground font-semibold">particuliers et professionnels</span>. 
                Une image de confiance, efficacité et propreté impeccable pour tous vos espaces.
              </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild size="lg" className="rounded-full px-8 h-14 text-lg">
                <Link href="#contact" className="gap-2">
                  Demander un devis <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="rounded-full px-8 h-14 text-lg">
                <Link href="#services">
                  Nos services
                </Link>
              </Button>
            </div>

            <div className="mt-12 flex items-center gap-8">
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-primary">100%</span>
                <span className="text-sm text-muted-foreground">Satisfaction client</span>
              </div>
              <div className="w-px h-10 bg-border" />
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-primary">24/7</span>
                <span className="text-sm text-muted-foreground">Disponibilité</span>
              </div>
              <div className="w-px h-10 bg-border" />
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-primary">Pro</span>
                <span className="text-sm text-muted-foreground">Équipe qualifiée</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Decorative element */}
      <div className="absolute bottom-10 right-10 hidden lg:block animate-bounce text-muted-foreground">
        <div className="flex flex-col items-center gap-2">
          <span className="text-xs font-medium uppercase tracking-widest vertical-text">Scroll</span>
          <div className="w-px h-12 bg-muted-foreground/30" />
        </div>
      </div>
    </section>
  );
}
