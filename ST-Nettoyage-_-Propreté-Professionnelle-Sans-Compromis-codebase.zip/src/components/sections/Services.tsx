"use client";

import { motion } from "framer-motion";
import { Home, Key, Shirt, RotateCcw, Layout, Building2, Layers } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const services = [
  {
    title: "Nettoyage de logements",
    description: "Un entretien complet et méticuleux de votre résidence pour un environnement sain et agréable au quotidien.",
    icon: Home,
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/IMG_9544-1-resized-1766953906072.jpeg?width=8000&height=8000&resize=contain"
  },
  {
    title: "Ménage Airbnb & Locations",
    description: "Service spécialisé pour les hôtes : préparation rapide et parfaite entre deux réservations pour des voyageurs ravis.",
    icon: Key,
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/IMG_9086-1-resized-1766954304336.jpeg?width=8000&height=8000&resize=contain"
  },
  {
    title: "Nettoyage de vitres",
    description: "Nettoyage professionnel intérieur et extérieur pour bureaux, immeubles, vitrines et toutes surfaces vitrées.",
    icon: Layout,
    image: "https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&q=80&w=800"
  },
  {
    title: "Nettoyage de bureaux",
    description: "Entretien de locaux professionnels, entreprises et open spaces pour un cadre de travail sain et productif.",
    icon: Building2,
    image: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=800"
  },
  {
    title: "Parties communes",
    description: "Nettoyage expert des halls, escaliers, couloirs et sanitaires pour le confort de tous les résidents.",
    icon: Layers,
    image: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&q=80&w=800"
  },
  {
    title: "Nettoyage après départ",
    description: "Remise en état complète après un déménagement ou des travaux. Nous effaçons toute trace pour un logement comme neuf.",
    icon: RotateCcw,
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/3BB576C4-D6A7-4283-A476-CEE36E4E3381-1-1766954135361.jpeg?width=8000&height=8000&resize=contain"
  },
  {
    title: "Gestion du linge",
    description: "Lavage, séchage et repassage de vos draps et serviettes. Un linge frais et impeccable pour chaque nouvel arrivant.",
    icon: Shirt,
    image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/9936E415-C84C-4033-8874-AC17921B2409-resized-1766953906069.jpeg?width=8000&height=8000&resize=contain"
  },
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-4">
              Nos Services
            </h2>
            <h3 className="text-3xl md:text-5xl font-bold mb-6 text-foreground">
              Des solutions sur mesure pour particuliers et professionnels
            </h3>
            <div className="w-24 h-1.5 bg-primary mx-auto rounded-full" />
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full border-none shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 group hover:-translate-y-2 flex flex-col">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-primary/20 group-hover:bg-transparent transition-colors duration-300" />
                  <div className="absolute top-4 left-4 w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-lg group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
                    <service.icon className="h-6 w-6" />
                  </div>
                </div>
                <CardHeader className="pb-2 pt-6">
                  <CardTitle className="text-xl font-bold">{service.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
