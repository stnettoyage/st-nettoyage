import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { Resend } from "resend";

export async function POST(req: Request) {
  try {
    const data = await req.json();
    const { nom_complet, email, telephone, type_service, message } = data;

    // 1. Save to Supabase
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !supabaseServiceRoleKey) {
      console.error("Missing Supabase configuration");
      return NextResponse.json({ error: "Configuration Supabase manquante" }, { status: 500 });
    }

    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey);

    const { error: dbError } = await supabase
      .from("devis_st_nettoyage")
      .insert([{ nom_complet, email, telephone, type_service, message }]);

    if (dbError) {
      console.error("Database error:", dbError);
      return NextResponse.json({ error: "Erreur lors de l'enregistrement en base de données" }, { status: 500 });
    }

    // 2. Send email via Resend
    const resendApiKey = process.env.RESEND_API_KEY;
    
    if (!resendApiKey) {
      return NextResponse.json({ 
        success: true, 
        warning: "Devis enregistré mais l'email n'a pas pu être envoyé (Clé API manquante)" 
      });
    }

    const resend = new Resend(resendApiKey);
    
    try {
      const { error: resendError } = await resend.emails.send({
        from: "ST Nettoyage Pro <onboarding@resend.dev>",
        to: ["st.nettoyagepro@gmail.com"],
        subject: "📩 Nouveau devis reçu - ST Nettoyage Pro",
        html: `
          <div style="font-family: sans-serif; line-height: 1.6; color: #333;">
            <h2 style="color: #000;">Nouveau devis reçu</h2>
            <p><strong>Nom :</strong> ${nom_complet}</p>
            <p><strong>Email :</strong> ${email}</p>
            <p><strong>Téléphone :</strong> ${telephone}</p>
            <p><strong>Type de service :</strong> ${type_service}</p>
            <p><strong>Message :</strong></p>
            <blockquote style="background: #f9f9f9; padding: 10px; border-left: 5px solid #ccc;">
              ${message || "Aucun message"}
            </blockquote>
          </div>
        `,
      });

      if (resendError) {
        console.error("ERREUR RESEND (API) :", resendError);
      } else {
        console.log("SUCCÈS RESEND : Email envoyé avec ID", resendData?.id);
      }
    } catch (emailError) {
      console.error("ERREUR CRITIQUE lors de l'appel Resend :", emailError);
    }

    console.log("LOG SERVEUR: Fin du processus Resend");
    console.log("-----------------------------------------");

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error("API Error:", error);
    return NextResponse.json({ error: error.message || "Une erreur interne est survenue" }, { status: 500 });
  }
}
